
#include "FruitObject.h"

FruitObject::FruitObject()
{
    x_val_fruit = 0;
    y_val_fruit = 0;
    is_move_fruit = false;
}

FruitObject::~FruitObject()
{

}

void FruitObject::HandleMoveFruit(const int& x_border, const int& y_border)
{
    rect_.y += y_val_fruit;
    if (rect_.y > SCREEN_HEIGHT)
    {
        is_move_fruit = false;
        rect_.y = -80;
    }
}



