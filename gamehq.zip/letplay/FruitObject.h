
#ifndef FRUITOBJECT_H_INCLUDED
#define FRUITOBJECT_H_INCLUDED

#include "CommonFunc.h"
#include "BaseObject.h"

class FruitObject : public BaseObject
{
public:
    FruitObject();
    ~FruitObject();

    void set_x_val_fruit(const int& xVal){x_val_fruit = xVal;}
    void set_y_val_fruit(const int& yVal){y_val_fruit = yVal;}
    int get_x_val_fruit() const {return x_val_fruit;}
    int get_y_val_fruit() const {return y_val_fruit;}

    void set_is_move_fruit(const bool& isMove){is_move_fruit = isMove;}
    bool get_is_move_fruit() const {return is_move_fruit;}

    void HandleMoveFruit(const int& x_border, const int& y_border);

private:
    int x_val_fruit;
    int y_val_fruit;
    bool is_move_fruit;
};


#endif
