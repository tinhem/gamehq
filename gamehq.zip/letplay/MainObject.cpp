
#include "MainObject.h"
#include "CommonFunc.h"
#include"FruitObject.h"

MainObject::MainObject()
{
    x_pos_ = 0;
    y_pos_ = 0;
    x_val_ = 0;
    y_val_ = 0;

}

MainObject::~MainObject()
{

}



bool MainObject::LoadImg(std::string path, SDL_Renderer* screen)
{
    bool ret = BaseObject::LoadImg(path, screen);

    return ret;
}

void MainObject::Show(SDL_Renderer* des)
{
    LoadImg("img//mokey2.png", des);

    rect_.x = x_pos_-40;
    rect_.y = y_pos_-80;

    SDL_Rect renderQuad = {rect_.x, rect_.y, 200, 140};
    SDL_RenderCopy(des, p_object_, NULL, &renderQuad);
}

void MainObject::HandelInputAction(SDL_Event events, SDL_Renderer* screen)
{
     if( events.type == SDL_MOUSEMOTION )
	{

		SDL_GetMouseState( &x_pos_, &y_pos_ );

	}
}

void MainObject::HandelFruitAction(SDL_Renderer* screen)
{
    if ((SDL_GetTicks()%90) == 0)
    {
        hoaqua_rand = rand()%4;
        int array[6]={0,140,280,420,560,800};
        FruitObject* p_fruit = new FruitObject();
        switch(hoaqua_rand)
        {
            case 0:p_fruit->LoadImg("img//banana2.png", screen);
            break;

            case 1:p_fruit->LoadImg("img//durian.png", screen);
            break;

            case 2:p_fruit->LoadImg("img//xoai.png", screen);
            break;

            case 3:p_fruit->LoadImg("img//tao.png", screen);
            break;
        }

  if (p_fruit_list_.size() == 0)
        {
            x_rand = array[rand()%6];

        }
        else
        {
            int y = array[rand()%6];
            while (y == x_rand)
            {
                y = array[rand()%6];
            }
            x_rand = y;
        }
        p_fruit->SetRect(x_rand, -80);
        if( (mark_value % 20) == 0 && mark_value > 0)
        {
            speed_fruit++;
        }
        p_fruit->set_y_val_fruit(speed_fruit);
        p_fruit->set_is_move_fruit(true);

        p_fruit_list_.push_back(p_fruit);
    }
}
void MainObject::HandleFruit(SDL_Renderer* des)
{
    for (int i=0; i < p_fruit_list_.size(); i++)
    {
        FruitObject* p_fruit = p_fruit_list_.at(i);
        if (p_fruit != NULL)
        {
            if (p_fruit->get_is_move_fruit() == true)
            {
                p_fruit->HandleMoveFruit(SCREEN_WIDTH, SCREEN_HEIGHT);
                p_fruit->Render(des);
            }
            else
            {
                p_fruit_list_.erase(p_fruit_list_.begin() + i);
                if (p_fruit != NULL)
                {
                    delete p_fruit;
                    p_fruit = NULL;
                }
            }
        }
    }
}
void MainObject::CheckCollisionFruit(MainObject p_player)
{

}
