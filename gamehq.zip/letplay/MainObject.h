
#ifndef MAINOBJECT_H_INCLUDED
#define MAINOBJECT_H_INCLUDED
#include<vector>
#include"FruitObject.h"
#include "CommonFunc.h"
#include "BaseObject.h"
class MainObject : public BaseObject
{
public:
    MainObject();
    ~MainObject();

    bool LoadImg(std:: string path, SDL_Renderer* screen );
    void Show(SDL_Renderer* des);
    void HandelInputAction(SDL_Event events, SDL_Renderer* screen);
    void HandelFruitAction(SDL_Renderer* screen  );




    void set_fruit_list(std::vector<FruitObject*> fruit_list)
    {
        p_fruit_list_ = fruit_list;
    }

    std::vector<FruitObject*> get_fruit_list() const {return p_fruit_list_;}
    void HandleFruit(SDL_Renderer* des);
    void CheckCollisionFruit(MainObject p_player);

private:
    std::vector<FruitObject*> p_fruit_list_;
    double x_val_;
    double y_val_;

    int x_pos_;
    int y_pos_;


};


#endif // MAINOBJECT_H_INCLUDED
