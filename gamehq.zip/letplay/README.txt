HUNGHQ:
Nội dung trò chơi:
- Bạn có 100 giây để hứng các loại hoa quả rơi xuống.
- Nếu sau 100 giây , số hoa quả vượt qua bạn không quá 5 quả thì bạn thắng , ngược lại thì bạn thua .


hướng dẫn:
- Dùng chuột để di chuyển nhân vật chính.

điểm số :
- Mỗi quả bạn hứng được tương ứng với 1 điểm.