#include <iostream>
#include"commonfunc.h"
#include"BaseObject.h"
#include"MainObject.h"
#include"FruitObject.h"
#include"TextObject.h"
#include"lbutton.h"
using namespace std;

BaseObject g_background;
BaseObject g_background_menu;
BaseObject g_background_win;
BaseObject g_background_loss;


bool InitData()
{
	//Initialization flag
	bool success = true;

	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO | SDL_INIT_AUDIO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		g_window = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
		if( g_window == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create vsynced renderer for window
			g_screen = SDL_CreateRenderer( g_window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
			if( g_screen == NULL )
			{
				printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
				success = false;
			}
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( g_screen, 0xff, 0xff, 0xff, 0xff );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
					success = false;
				}

				if (TTF_Init() == -1)
                {
                    printf("SDL_TTF failed",TTF_GetError());
                    success = false;
                }

                font_mark = TTF_OpenFont("font//mark.ttf",25);

                if(font_mark == NULL)
                {
                	std::cout<<" load  font mark false";
                    success = false;
                }

                font_time = TTF_OpenFont("font//time.ttf", 30);
                if(font_time == NULL)
                {
                    success = false;
                }

			}
		}
	}

	return success;
}

   bool LoadBackground()
{
    bool ret = g_background.LoadImg("img//bkground.jpg",g_screen);
    bool ret_2 = g_background_menu.LoadImg("img//background_menu.png" , g_screen);
	bool win = g_background_win.LoadImg("img//win.png" , g_screen);
	bool loss = g_background_loss.LoadImg("img//loss.png" , g_screen);

    if (ret == false) return false;
    if(ret_2 == false) return false;
    if (win == false) return false;
    if (loss == false) return false;


    return true;
}
void close()
{
    g_background.Free();
    g_background_menu.Free();
    SDL_DestroyRenderer(g_screen);
    g_screen = NULL;

    SDL_DestroyWindow(g_window);
    g_window = NULL;

    IMG_Quit();
    SDL_Quit();

}

int main(int argc, char* argv[])
{
   srand((int)time(0));
    if (InitData() == false ){
        return -1;
    }
    if (LoadBackground() == false){
        return -1;
    }

	bool is_quit = false;
    while(!is_quit)
    {
        while(SDL_PollEvent(&g_event)!= 0)
        {
            if(g_event.type == SDL_QUIT)
            {
                is_quit = true;
            }

        }
        SDL_SetRenderDrawColor(g_screen,0xff, 0xff, 0xff, 0xff);
		SDL_RenderClear(g_screen);

		g_background_menu.Render(g_screen, NULL);

		SDL_RenderPresent(g_screen);

		if(g_event.type == SDL_KEYDOWN)
		{
			MainObject p_player;
			p_player.LoadImg("img//mokey2.png", g_screen);


         TextObject time_game;
			time_game.SetColor(TextObject::WHITE_TEXT);

			TextObject mark_game;
			mark_game.SetColor(TextObject::WHITE_TEXT);
			int mark_value = 0;

			while(!is_quit)
			{
				while(SDL_PollEvent(&g_event)!= 0)
				{
					if(g_event.type == SDL_QUIT)
					{
						is_quit = true;
					}

					p_player.HandelInputAction(g_event, g_screen);
				}

				SDL_SetRenderDrawColor(g_screen,0xff, 0xff, 0xff, 0xff);
				SDL_RenderClear(g_screen);

                g_background.Render(g_screen, NULL);
                p_player.HandelFruitAction(g_screen );
				p_player.HandleFruit(g_screen);

				p_player.Show(g_screen);
       std::vector<FruitObject*> fruit_list = p_player.get_fruit_list();
                for(int i = 0; i<fruit_list.size();i++)
                {
                    FruitObject* ob_fruit = fruit_list[i];
                    if(ob_fruit != NULL)
                    {
                        SDL_Rect fRect;
                        fRect.y = ob_fruit->GetRect().y;
                        if (fRect.y >= SCREEN_HEIGHT)
                        {
                            num_fruit_over++;
							if (num_fruit_over == 5)
                            {
                            	bool quit_game = false;
                            	while(!quit_game)
								{


									SDL_SetRenderDrawColor(g_screen,0xff, 0xff, 0xff, 0xff);
									SDL_RenderClear(g_screen);


									g_background_loss.Render(g_screen , NULL);
									SDL_RenderPresent(g_screen);

									while(SDL_PollEvent(&g_event)!= 0)
										{

											if(g_event.type == SDL_QUIT || g_event.type == SDL_KEYDOWN)
											{
												is_quit = true;
												quit_game = true;
											}

										}
								}


                            }
                        }


                    }

                }

            for(int t = 0; t<fruit_list.size();t++)
                {
                    FruitObject* j_fruit = fruit_list.at(t);
                    if(j_fruit != NULL)
                    {
                        SDL_Rect fRect;
                                fRect.y = j_fruit->GetRect().y;
                                fRect.x = j_fruit->GetRect().x;
                                fRect.w=95;
                                fRect.h=80;

  bool bCol = SDLCommonFunc::CheckCollision(p_player.GetRect(), fRect);
  if (bCol)
								{
									mark_value+=1;
									j_fruit->Free();
									fruit_list.erase(fruit_list.begin() + t );



								}
                    }
                }


                std::string str_time = "Time: ";
				int time_val = SDL_GetTicks()/1000;

				int time_limit = 0;
				time_limit +=time_val;



				std::string str_val = std::to_string(time_val);
				str_time += str_val;

				time_game.SetText(str_time);
				time_game.LoadFromRenderText(font_time, g_screen);
				time_game.RenderText(g_screen, 800,15);


				std::string val_str_mark = std:: to_string(mark_value);
				std::string strMark("Mark: ");
				strMark += val_str_mark;

				mark_game.SetText(strMark);
				mark_game.LoadFromRenderText( font_mark , g_screen);
				mark_game.RenderText(g_screen,45, 15);

				if(time_limit > 100)
				{
					mark_game.Free();
					time_game.Free();

					SDL_SetRenderDrawColor(g_screen,0xff, 0xff, 0xff, 0xff);
					SDL_RenderClear(g_screen);


					g_background_win.Render(g_screen , NULL);
					SDL_RenderPresent(g_screen);

					 while(SDL_PollEvent(&g_event)!= 0)
					{
						if(g_event.type == SDL_QUIT || g_event.type == SDL_KEYDOWN)
						{
							is_quit = true;
						}

					}


				}

       SDL_RenderPresent(g_screen);

			}
		}
    }
close();
    return 0;
}
